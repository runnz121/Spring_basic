package Spring.SpringCRUD;

import Spring.SpringCRUD.Order.OrderService;
import Spring.SpringCRUD.Order.OrderServiceImpl;
import Spring.SpringCRUD.discount.DiscountPolicy;
import Spring.SpringCRUD.discount.FixDiscountPolicy;
import Spring.SpringCRUD.discount.RateDiscountPolicy;
import Spring.SpringCRUD.member.MemberRepository;
import Spring.SpringCRUD.member.MemberService;
import Spring.SpringCRUD.member.MemberServiceImpl;
import Spring.SpringCRUD.member.MemoryMemberRepository;

public class AppConfig { //환경설정은 모두 여기서 지정한다

    //memberservice 구현
    public MemberService memberService() {
        return new MemberServiceImpl(memberRepository()); //생성자 주입(new로 생성된 생성자를 통해서 주입)
                                                                    // memberService로 호출이 들어오면 MemberServiceImpl의 MemoryMemberRepository객체에 할당이 된다.

    }

    private MemberRepository memberRepository() {
        return new MemoryMemberRepository();
    }

    //orderservice 구현
    public OrderService orderService() {
        return new OrderServiceImpl(memberRepository(), discountPolicy()); //여기는 memberRepository와 discountPolicy 2개의 field가 존재
    }                               //ctrl + alt + m 으로 해당 변수를(원래는 new memberRepository)를 리펙토링 해준다 이때 구현체를 선택

    public DiscountPolicy discountPolicy(){
        //return new FixDiscountPolicy();
        return new RateDiscountPolicy(); //새로운 할인정책 적용시 이코드로변경만 해주면 된다
    }


}
