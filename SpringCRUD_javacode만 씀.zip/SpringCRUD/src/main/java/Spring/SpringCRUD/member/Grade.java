package Spring.SpringCRUD.member;

public enum Grade { //회원에 대한 등급 구현
    BASIC,
    VIP
}
